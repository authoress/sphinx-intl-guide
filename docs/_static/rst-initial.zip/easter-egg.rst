Easter Egg
========== 

In Python interactive prompt, run:

::

  >>> import this

Enjoy your easter egg!